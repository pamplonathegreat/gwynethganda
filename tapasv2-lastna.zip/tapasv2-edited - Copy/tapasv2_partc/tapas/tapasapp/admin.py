from django.contrib import admin
from .models import Dish, Account

# Register your models here.
admin.site.register(Dish)
admin.site.register(Account)
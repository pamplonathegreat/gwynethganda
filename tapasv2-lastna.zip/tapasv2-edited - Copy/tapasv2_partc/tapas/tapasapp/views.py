from django.shortcuts import render, redirect, get_object_or_404
from .models import Dish, Account
from django.contrib import messages
from django.urls import reverse
# Create your views here.
def basic_list(request, pk):
    account = get_object_or_404(Account, pk=pk)
    return render(request, 'basic_list.html', {'account': account})

def manage_account(request,pk):
    account = get_object_or_404(Account,pk=pk)
    return render(request, 'tapasapp/manage_account.html', {'account':account})

def delete_account(request,pk):
    Account.objects.filter(pk=pk).delete()
    return render(request, 'tapasapp/log_in.html')

def change_password(request,pk):
    account = get_object_or_404(Account,pk=pk)

    if(request.method=="POST"):
        current_password = request.POST.get('inputOldPassword')
        new_password1 = request.POST.get('inputNewPassword')
        new_password2 = request.POST.get('inputNewPasswordAgain')
        Account.objects.filter(pk=pk).update(password=new_password1)
        return render(request, 'tapasapp/manage_account.html', {'account':account})
    else:
        return render(request, 'tapasapp/change_password.html', {'account':account})
    



def log_in(request):
    error_message = None

    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')

        users = Account.objects.filter(username=username)
        if users.exists():
            user = users.first()
            if user.password == password:
                return redirect(reverse('better_menu', kwargs={'pk': user.pk}))
            else:
                error_message = 'Invalid password. Please try again.'
        else:
            error_message = 'Invalid login. Please sign up to create an account.'
    
    return render(request, 'log_in.html', {'error_message': error_message})
    

def sign_up(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']

        # check if username is taken
        if Account.objects.filter(username=username).exists():
            error_message_username = 'Account already exists!'
            return render(request, 'sign_up.html', {'error_message_username': error_message_username})
        
        else:
        # create user
            Account.objects.create(username=username, password=password)
            messages.success(request, 'Account created successfully!')
            return redirect('log_in')
    else:
        return render(request, 'sign_up.html')
    
def better_menu(request, pk):
    dish_objects = Dish.objects.all()
    return render(request, 'tapasapp/better_list.html', {'dishes':dish_objects})

def add_menu(request):
    if(request.method=="POST"):
        dishname = request.POST.get('dname')
        cooktime = request.POST.get('ctime')
        preptime = request.POST.get('ptime')
        Dish.objects.create(name=dishname, cook_time=cooktime, prep_time=preptime)
        return redirect('better_menu')
    else:
        return render(request, 'tapasapp/add_menu.html')

def view_detail(request, pk):
    d = get_object_or_404(Dish, pk=pk)
    return render(request, 'tapasapp/view_detail.html', {'d': d})

def delete_dish(request, pk):
    Dish.objects.filter(pk=pk).delete()
    return redirect('better_menu')

def update_dish(request, pk):
    if(request.method=="POST"):
        cooktime = request.POST.get('ctime')
        preptime = request.POST.get('ptime')
        Dish.objects.filter(pk=pk).update(cook_time=cooktime, prep_time=preptime)
        return redirect('view_detail', pk=pk)
    else:
        d = get_object_or_404(Dish, pk=pk)
        return render(request, 'tapasapp/update_menu.html', {'d':d})